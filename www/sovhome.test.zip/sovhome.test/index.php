<?php
	session_start ();

	date_default_timezone_set('Asia/Yekaterinburg');

	require_once ($_SERVER['DOCUMENT_ROOT'].'/system/functions.php'); // стартуем функции

	if ($_SESSION['user']){
	header ('Location: profile.php');
	}

	head();
?>
		<div class="test">
			<!--Форма авторизации -->
			<form action="/system/singin.php" method="POST">
				<label>Логин</label>
				<input type="text" placeholder="Введите логин" name="login">
				<label>Пароль</label>
				<input type="password" placeholder="Подтвердите пароль" name="password">
				<button type="submit">Войти</button>
				<p>
					У вас нет аккаунта? - <a href="register.php">зарегистрируйтесь</a>
				</p>
				<?php 

				if (isset ($_SESSION['message'])) {
				// если есть ошибка выводим сообщение
					echo '<p class="msg"> ' . $_SESSION['message'] . '</p>';
				}
				unset ($_SESSION['message']);
			?>
			</form>
		</div>


<!-- <?php

	foot(); 
	exit;

?> -->