<?php 
	session_start ();
	require_once 'core.php';

	$full_name = $_POST['full_name'];
	$login = $_POST['login'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password_confirm = $_POST['password_confirm'];
	

	if ($password === $password_confirm) {
		//если пароли совпадают передаём данные в базу.
		$db_pass = password_hash($password, PASSWORD_DEFAULT);
		mysqli_query ($connect, "INSERT INTO `users` (`id`, `full_name`, `login`, `email`, `password`, `creation_time`) VALUES (NULL, '$full_name', '$login', '$email', '$db_pass', NOW())");
		$_SESSION['message'] = 'Регистрация прошла успешно';
		header ('Location: ../indexauth.php');
	} else {
		//пароли не совпадают
		$_SESSION['message'] = 'Пароли не совпадают!';
		header ('Location: register.php');
	}

?>