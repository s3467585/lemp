<?php
	session_start ();

	if ($_SESSION['user']){
	header ('Location: profile.php');
	}
?> 
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Авторизация и регистация</title>
		<link rel="stylesheet" type="text/css" href="../style/style.css">
	</head>
	<body>
		<!--Форма авторизации -->
		<form action="singup.php" method="POST">
			<label>Ф.И.О</label>
			<input type="text" placeholder="Введите своё полное имя" name="full_name">
			<label>Логин</label>
			<input type="text" placeholder="Введите свой логин" name="login">
			<label>E-Mail</label>
			<input type="text" placeholder="Введите адрес своей почты" name="email">
			<label>Пароль</label>
			<input type="password" placeholder="Введите пароль" name="password">
			<label>Подтверждение пароля</label>
			<input type="password" placeholder="Подтвердите пароль" name="password_confirm">
			<button type="submit">Зарегистрироваться</button>
			<p class="msg">
				У вас есть аккаунт? - <a href="auth.php">авторизуйтесь</a>
			</p>
			<?php 
				if (isset ($_SESSION['message'])) {
				// если есть ошибка выводим сообщение
					echo '<p class="msg"> ' . $_SESSION['message'] . '</p>';
				}
				unset ($_SESSION['message']);
			?>
			
		</form>
	</body>
</html>