-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 06 2024 г., 07:56
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `s92243jz_sovhome`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sensor`
--
-- Создание: Окт 10 2022 г., 03:13
-- Последнее обновление: Окт 10 2022 г., 03:13
--

DROP TABLE IF EXISTS `sensor`;
CREATE TABLE `sensor` (
  `pir1` int(2) NOT NULL,
  `pir2` int(2) NOT NULL,
  `rele1` int(2) NOT NULL,
  `light` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sensor`
--

INSERT INTO `sensor` (`pir1`, `pir2`, `rele1`, `light`) VALUES
(0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--
-- Создание: Окт 10 2022 г., 03:13
-- Последнее обновление: Ноя 07 2023 г., 05:17
-- Последняя проверка: Авг 24 2023 г., 12:00
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` varchar(50) NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `value`) VALUES
('connection', '1698829115'),
('reboot', '1698809092'),
('ram', '1024'),
('mailSendTime', '');

-- --------------------------------------------------------

--
-- Структура таблицы `settings_mari`
--
-- Создание: Ноя 01 2023 г., 10:51
-- Последнее обновление: Май 06 2024 г., 04:35
--

DROP TABLE IF EXISTS `settings_mari`;
CREATE TABLE `settings_mari` (
  `id` varchar(50) NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `settings_mari`
--

INSERT INTO `settings_mari` (`id`, `value`) VALUES
('connection', '1714969974'),
('reboot', '1712616001'),
('ram', '1024'),
('mailSendTime', '1714513354'),
('tempAlarm', '20');

-- --------------------------------------------------------

--
-- Структура таблицы `settings_sovhome`
--
-- Создание: Май 06 2024 г., 04:33
-- Последнее обновление: Май 06 2024 г., 04:38
--

DROP TABLE IF EXISTS `settings_sovhome`;
CREATE TABLE `settings_sovhome` (
  `id` varchar(50) NOT NULL,
  `value` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `settings_sovhome`
--

INSERT INTO `settings_sovhome` (`id`, `value`) VALUES
('connection', '1714970333'),
('reboot', '1698896397'),
('ram', '1024'),
('mailSendTime', '1706577357'),
('tempAlarm', '20');

-- --------------------------------------------------------

--
-- Структура таблицы `stat`
--
-- Создание: Окт 10 2022 г., 03:13
-- Последнее обновление: Ноя 01 2023 г., 08:58
-- Последняя проверка: Авг 24 2023 г., 12:00
--

DROP TABLE IF EXISTS `stat`;
CREATE TABLE `stat` (
  `id` int(20) NOT NULL,
  `temp0` int(5) NOT NULL,
  `temp1` int(5) NOT NULL,
  `temp2` int(5) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stat`
--

INSERT INTO `stat` (`id`, `temp0`, `temp1`, `temp2`, `time`) VALUES
(59081, -5, 63, 46, 1698809084),
(59080, -127, 0, 0, 1698808378),
(59079, -5, 63, 46, 1698807833),
(59094, -2, 63, 47, 1698829115),
(59093, -2, 64, 47, 1698827860),
(59092, -2, 63, 48, 1698826609),
(59091, -2, 63, 47, 1698825357),
(59090, -2, 63, 47, 1698824105),
(59089, -3, 63, 46, 1698822853),
(59088, -4, 63, 46, 1698821602),
(59087, -4, 63, 46, 1698820350),
(59086, -4, 63, 46, 1698816595),
(59085, -5, 63, 46, 1698812839),
(59084, -5, 63, 46, 1698811588),
(59083, -5, 63, 46, 1698810336),
(59082, -127, 0, 0, 1698809095);

-- --------------------------------------------------------

--
-- Структура таблицы `stat_mari`
--
-- Создание: Ноя 02 2023 г., 03:37
-- Последнее обновление: Май 06 2024 г., 04:32
--

DROP TABLE IF EXISTS `stat_mari`;
CREATE TABLE `stat_mari` (
  `id` int(11) NOT NULL,
  `temp0` int(5) NOT NULL,
  `temp1` int(5) NOT NULL,
  `temp2` int(5) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stat_mari`
--

INSERT INTO `stat_mari` (`id`, `temp0`, `temp1`, `temp2`, `time`) VALUES
(3138, 1, 39, 24, 1714910390),
(3139, 1, 39, 24, 1714915238),
(3140, 1, 36, 24, 1714916450),
(3141, 0, 30, 24, 1714917853),
(3142, -1, 39, 24, 1714920277),
(3143, -5, 39, 24, 1714928762),
(3144, -4, 33, 24, 1714933611),
(3145, -5, 38, 24, 1714937247),
(3146, -6, 35, 24, 1714938459),
(3147, -6, 28, 23, 1714940884),
(3148, -6, 27, 23, 1714942096),
(3149, -6, 27, 23, 1714943308),
(3150, -7, 26, 23, 1714945732),
(3151, -7, 25, 22, 1714946944),
(3152, -7, 25, 22, 1714948156),
(3153, -7, 25, 22, 1714949368),
(3154, -8, 24, 22, 1714950580),
(3155, 1, 24, 22, 1714955429),
(3156, 5, 23, 22, 1714956641),
(3157, 9, 23, 22, 1714957853),
(3158, 9, 32, 22, 1714959065),
(3159, 14, 28, 23, 1714962702),
(3160, 15, 26, 23, 1714963914),
(3161, 16, 24, 23, 1714967550),
(3162, 15, 24, 23, 1714969974);

-- --------------------------------------------------------

--
-- Структура таблицы `stat_sovhome`
--
-- Создание: Ноя 02 2023 г., 03:36
-- Последнее обновление: Май 06 2024 г., 04:38
--

DROP TABLE IF EXISTS `stat_sovhome`;
CREATE TABLE `stat_sovhome` (
  `id` int(11) NOT NULL,
  `temp0` int(5) NOT NULL,
  `temp1` int(5) NOT NULL,
  `temp2` int(5) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `stat_sovhome`
--

INSERT INTO `stat_sovhome` (`id`, `temp0`, `temp1`, `temp2`, `time`) VALUES
(9646, -1, 40, 30, 1714934037),
(9647, -1, 40, 30, 1714935288),
(9648, -2, 40, 30, 1714936540),
(9649, -3, 40, 30, 1714939043),
(9650, -4, 40, 30, 1714940295),
(9651, -4, 40, 30, 1714941546),
(9652, -4, 40, 30, 1714944050),
(9653, -5, 40, 30, 1714945301),
(9654, -5, 40, 30, 1714946553),
(9655, -5, 39, 30, 1714947804),
(9656, -6, 40, 30, 1714949056),
(9657, -6, 40, 30, 1714950307),
(9658, -6, 40, 30, 1714951559),
(9659, -5, 39, 30, 1714954062),
(9660, -5, 39, 30, 1714955314),
(9661, -4, 39, 30, 1714956565),
(9662, -2, 40, 30, 1714957817),
(9663, -1, 40, 30, 1714959068),
(9664, -1, 40, 30, 1714960320),
(9665, 0, 40, 30, 1714961571),
(9666, 1, 40, 30, 1714962823),
(9667, 2, 40, 30, 1714964075),
(9668, 3, 40, 30, 1714965326),
(9669, 4, 40, 30, 1714969081),
(9670, 6, 40, 30, 1714970333);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `stat`
--
ALTER TABLE `stat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Индексы таблицы `stat_mari`
--
ALTER TABLE `stat_mari`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `stat_sovhome`
--
ALTER TABLE `stat_sovhome`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `stat`
--
ALTER TABLE `stat`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59095;

--
-- AUTO_INCREMENT для таблицы `stat_mari`
--
ALTER TABLE `stat_mari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3163;

--
-- AUTO_INCREMENT для таблицы `stat_sovhome`
--
ALTER TABLE `stat_sovhome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9671;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
