 <a href=/test/alt.php>TEST</a>
 <a href=/style/body.php>BODY</a>
</div>
</body>
</html>