<?php
     require_once ($_SERVER['DOCUMENT_ROOT'].'/system/functions.php'); // стартуем функции

	error_reporting(E_ALL);
	ini_set('display_errors', 'On'); 

	    
	body();
	echo "test message";
?>

