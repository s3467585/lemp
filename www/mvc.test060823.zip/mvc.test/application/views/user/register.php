<h1>Регистрация</h1>
<form>
	<p>Логин</p>
	<p><input type="text" name=""></p>
	<p>Пароль</p>
	<p><input type="text" name=""></p>
	<p><button>Регистрация</button></p>
</form>