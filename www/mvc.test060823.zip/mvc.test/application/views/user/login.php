<h1>Вход</h1>

<form action="/account/login" method="POST">
	
	<p>Логин</p>
	<p><input type="text" name="login"></p>

	<p>Пароль</p>
	<p><input type="text" name="password"></p>

	<p><button type="submit" name="enter">Вход</button></p>

</form>