<p>Главная страница</p>

<!-- <?php foreach ($news as $value): ?>
		
	<h3><?php echo 'Подача: '.$value['temp0'];?></h3>
	<h3><?php echo 'Обратка: '.$value['temp0'];?></h3>
	<h3><?php echo 'Улица: '.$value['temp0'];?></h3>
	<hr>
	
<?php endforeach; ?> -->
    


