<?php
    
    return [

        'host' => 'lemp_mysql',
        'dbname'=>'s92243jz_sovhome',
        'bduser'=>'s92243jz_sovhome',
        'dbpassword'=>'qwerty',

    ];