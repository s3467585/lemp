<?php

return [

	'all' => [
		'login',
	],

	'autorizq' => [
		//
	],

	'quest' => [
		//
	],

	'admin' => [
		'login',
		'logout',
	],

];