<?php

return [

	'all' => [
		'index',
		'about',
		'contact',
	],

	'autorizq' => [
		//
	],

	'quest' => [
		//
	],

	'admin' => [
		//
	],

];