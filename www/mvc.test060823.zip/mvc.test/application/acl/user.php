<?php

return [

	'all' => [
		'login',
		'register',
	],

	'autorizq' => [
		//
	],

	'quest' => [
		//
	],

	'admin' => [
		//
	],

];